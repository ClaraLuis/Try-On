export const serverbaselink = "https://api.tabexseries.com";
export const imagebaselink = "https://ik.imagekit.io/to5erzdnjb";
